Winsh 2.2 Binary Distribution
-----------------------------
Sources at https://github.com/JohnHind/Winsh.lua.

Documentation in Winsh2-2.html.

Winshxxxab.exe files are various runtime versions.
'xxx' is a tag describing the inventory set.
'a' is either 'C' console or 'W' windows sub-system.
'b' is either 'S' standalone or 'D' DLL Lua.
The 'D' versions require WinshLua.dll either in the
same folder as the exe or in an App Folder.
To obtain detailed inventory, execute a 'W' exe and
take the Inventory option on the Help menu.
