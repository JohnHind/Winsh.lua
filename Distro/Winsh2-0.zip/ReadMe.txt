Winsh 2.0 Binary Distribution
-----------------------------
Sources at https://github.com/JohnHind/Winsh.lua

Documentation in Winsh2-0.html
WinshxxxWin.exe files are runtimes with different inventories.
Execute and then use Help/Inventory menu.
WinshxxxCon.exe files have the same inventory as the like-
named Win except they have the console subsystem flag. Run
these from the command window.
